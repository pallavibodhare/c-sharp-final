using System;
class Program
{
    static void Main()
    {
        for(int i=1;i<=20;i+=2)
        {
            Console.WriteLine(i);
        }
    }
}